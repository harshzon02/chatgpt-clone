// 1. REPLACE WITH YOUR OWN FIREBASE CONFIGURATION
const firebaseConfig = {
    apiKey: "YOUR_FIREBASE_API_KEY",
    authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
    projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_PROJECT_ID.appspot.com",
    messagingSenderId: "YOUR_SENDER_ID",
    appId: "YOUR_APP_ID"
};

const app = firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();

let inputField = document.querySelector("#questionInput");
let chatHistory = document.getElementById("chatHistory");
let profileIconDiv = document.getElementById('profileIcon');
let welcomeMessageDiv = document.getElementById('welcomeMessage');
let inputContainer = document.getElementById('inputContainer');

function appendMessage(sender, text) {
    const messageBubble = document.createElement('div');
    messageBubble.classList.add('message-bubble');
    
    if (sender === 'user') {
        messageBubble.classList.add('user-message');
    } else {
        messageBubble.classList.add('ai-message');
    }

    messageBubble.innerHTML = text;
    chatHistory.appendChild(messageBubble);

    chatHistory.scrollTop = chatHistory.scrollHeight;
}

async function gemini(query) {
    if (!query || query.trim() === "") {
        return;
    }

    setChatMode();

    appendMessage('user', query);
    
    const aiResponseBubble = document.createElement('div');
    aiResponseBubble.classList.add('message-bubble', 'ai-message');
    aiResponseBubble.textContent = "Generating response...";
    chatHistory.appendChild(aiResponseBubble);
    chatHistory.scrollTop = chatHistory.scrollHeight;

    try {
        const fullQuery = "Please format your response using Markdown. " + query;
        let response = await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=AIzaSyCiWoLQxZ9ZHsAA-ZjgVU55DOVfdCKfcNw", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                contents: [{ parts: [{ text: fullQuery }] }],
            })
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        let data = await response.json();
        let rawAnswer = data.candidates[0].content.parts[0].text;
        
        const formattedAnswer = marked.parse(rawAnswer);
        aiResponseBubble.innerHTML = formattedAnswer;

    } catch (error) {
        console.error("Error fetching Gemini response:", error);
        aiResponseBubble.textContent = "Error: Could not get a response. Please try again.";
    }
}

function startListening() {
    if (!('webkitSpeechRecognition' in window)) {
        alert('Web Speech API is not supported in this browser. Try Chrome or Firefox.');
        return;
    }

    const recognition = new webkitSpeechRecognition();
    recognition.lang = 'en-US';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    recognition.onresult = (event) => {
        const speechResult = event.results[0][0].transcript;
        inputField.value = speechResult;
    };

    recognition.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
    };

    recognition.onend = () => {
        console.log('Speech recognition service disconnected.');
    };

    recognition.start();
    console.log('Listening for voice input...');
}

function signInWithGoogle() {
    const provider = new firebase.auth.GoogleAuthProvider();
    auth.signInWithPopup(provider)
        .then((result) => {
            console.log("User logged in:", result.user);
        })
        .catch((error) => {
            console.error("Login failed:", error);
        });
}

auth.onAuthStateChanged((user) => {
    if (user) {
        profileIconDiv.innerHTML = `<img src="${user.photoURL}" style="width: 100%; border-radius: 50%;">`;
        profileIconDiv.removeEventListener('click', signInWithGoogle);
    } else {
        profileIconDiv.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-user"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>`;
        profileIconDiv.addEventListener('click', signInWithGoogle);
    }
});

inputField.addEventListener("keydown", function(event) {
    if (event.key === "Enter" && inputField.value.trim() !== "") {
        gemini(inputField.value.trim());
        inputField.value = "";
    }
});

function setChatMode() {
    welcomeMessageDiv.classList.add('hidden');
    chatHistory.classList.remove('hidden');
    inputContainer.classList.remove('centered');
    inputContainer.classList.add('bottom');
}

window.onload = function() {
    inputContainer.classList.add('centered');
};